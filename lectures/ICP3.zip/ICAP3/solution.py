import unittest


def count_shifts(arr):
    """
    This function should count the number of shifts required to sort the array using insertion sort.
    You need to implement the insertion sort algorithm and count how many shifts happen during sorting.

    Parameters:
    arr (list of int): The array of integers to be sorted

    Returns:
    int: The number of shifts (movements of elements) during sorting
    """
    pass  # You need to replace this with your code


class TestCountShifts(unittest.TestCase):

    def test_case_1(self):
        arr1 = [6, 7, 3, 9, 2, 9, 3, 4, 2, 8, 8]
        self.assertEqual(count_shifts(arr1), 25)

    def test_case_2(self):
        arr2 = [1, 2, 3, 4, 5]
        self.assertEqual(count_shifts(arr2), 0)


# Students need to add 3 more test cases following the same structure as above.

if __name__ == "__main__":
    unittest.main()